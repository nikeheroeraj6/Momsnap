package com.momsnap.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("momsnap", Context.MODE_PRIVATE) }
    private val projectionRequest = 4102
    private lateinit var token: EditText
    private lateinit var chatId: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 28)
            gravity = Gravity.CENTER_HORIZONTAL
        }
        root.addView(TextView(this).apply {
            text = "MomSnap\n\nWhen Mom taps the floating button, this app captures the screen and sends it to the Telegram account configured below. Screen capture is visible and requires Android permission."
            textSize = 17f
        })
        token = EditText(this).apply {
            hint = "Telegram bot token (keep private)"
            setText(prefs.getString("token", ""))
            singleLine = true
        }
        chatId = EditText(this).apply {
            hint = "Your Telegram chat ID"
            setText(prefs.getString("chat", ""))
            singleLine = true
        }
        root.addView(token)
        root.addView(chatId)
        root.addView(Button(this).apply {
            text = "Save Telegram settings"
            setOnClickListener {
                prefs.edit().putString("token", token.text.toString().trim())
                    .putString("chat", chatId.text.toString().trim()).apply()
                Toast.makeText(this@MainActivity, "Settings saved on this phone", Toast.LENGTH_SHORT).show()
            }
        })
        root.addView(Button(this).apply {
            text = "Enable floating screenshot button"
            setOnClickListener { enableCapture() }
        })
        root.addView(Button(this).apply {
            text = "Stop MomSnap"
            setOnClickListener { stopService(Intent(this@MainActivity, CaptureService::class.java)) }
        })
        setContentView(root)
    }

    private fun enableCapture() {
        val bot = token.text.toString().trim()
        val chat = chatId.text.toString().trim()
        if (bot.isBlank() || chat.isBlank()) {
            Toast.makeText(this, "Enter and save the bot token and chat ID first", Toast.LENGTH_LONG).show()
            return
        }
        prefs.edit().putString("token", bot).putString("chat", chat).apply()
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            Toast.makeText(this, "Allow display over other apps, then return and tap Enable again", Toast.LENGTH_LONG).show()
            return
        }
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(manager.createScreenCaptureIntent(), projectionRequest)
    }

    @Deprecated("Required for the Android MediaProjection consent result")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == projectionRequest && resultCode == RESULT_OK && data != null) {
            val service = Intent(this, CaptureService::class.java).apply {
                putExtra(CaptureService.EXTRA_RESULT_CODE, resultCode)
                putExtra(CaptureService.EXTRA_RESULT_DATA, data)
            }
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(service) else startService(service)
            Toast.makeText(this, "MomSnap is active. Tap the floating button to capture.", Toast.LENGTH_LONG).show()
        } else if (requestCode == projectionRequest) {
            Toast.makeText(this, "Screen capture permission was not granted", Toast.LENGTH_LONG).show()
        }
    }
}

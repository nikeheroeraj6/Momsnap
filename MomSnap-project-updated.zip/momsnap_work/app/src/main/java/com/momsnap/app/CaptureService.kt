package com.momsnap.app

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class CaptureService : Service() {
    companion object {
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        private const val CHANNEL = "momsnap_capture"
        private const val NOTIFICATION_ID = 72
    }

    private val executor = Executors.newSingleThreadExecutor()
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private var overlay: TextView? = null
    private var windowManager: WindowManager? = null
    private var busy = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createNotificationChannel()
        val notification = Notification.Builder(this, CHANNEL)
            .setContentTitle("MomSnap is active")
            .setContentText("Screen capture is available. Tap the floating button to send a screenshot.")
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIFICATION_ID, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(NOTIFICATION_ID, notification)

        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED) ?: Activity.RESULT_CANCELED
        val data = if (Build.VERSION.SDK_INT >= 33) intent?.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
                   else @Suppress("DEPRECATION") intent?.getParcelableExtra(EXTRA_RESULT_DATA) as? Intent
        if (resultCode != Activity.RESULT_OK || data == null) { stopSelf(); return START_NOT_STICKY }
        try {
            val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = mgr.getMediaProjection(resultCode, data)
            startProjection()
            showFloatingButton()
        } catch (_: Exception) {
            Toast.makeText(this, "Could not start screen capture. Please reopen MomSnap and grant permission.", Toast.LENGTH_LONG).show()
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun startProjection() {
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)
        val width = metrics.widthPixels
        val height = metrics.heightPixels
        val density = metrics.densityDpi
        reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        display = projection?.createVirtualDisplay("MomSnapCapture", width, height, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader?.surface, null, null)
    }

    private fun showFloatingButton() {
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val button = TextView(this).apply {
            text = "📸"
            textSize = 25f
            gravity = Gravity.CENTER
            setPadding(18, 12, 18, 12)
            setBackgroundColor(0xEE263238.toInt())
            contentDescription = "MomSnap screenshot button. Tap to capture and send screen."
            setOnClickListener { captureAndSend() }
        }
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.END or Gravity.CENTER_VERTICAL; x = 12 }
        try { windowManager?.addView(button, params); overlay = button } catch (_: Exception) { stopSelf() }
    }

    private fun captureAndSend() {
        if (busy) return
        busy = true
        Toast.makeText(this, "Capturing screen…", Toast.LENGTH_SHORT).show()
        executor.execute {
            try {
                Thread.sleep(350)
                val image = reader?.acquireLatestImage() ?: throw IllegalStateException("No screen frame available")
                val plane = image.planes[0]
                val buffer = plane.buffer
                val pixelStride = plane.pixelStride
                val rowStride = plane.rowStride
                val rowPadding = rowStride - pixelStride * image.width
                val bitmap = android.graphics.Bitmap.createBitmap(image.width + rowPadding / pixelStride, image.height, android.graphics.Bitmap.Config.ARGB_8888)
                bitmap.copyPixelsFromBuffer(buffer)
                image.close()
                val cropped = android.graphics.Bitmap.createBitmap(bitmap, 0, 0, imageWidth(bitmap), imageHeight(bitmap))
                val bytes = ByteArrayOutputStream().use { out -> cropped.compress(android.graphics.Bitmap.CompressFormat.JPEG, 85, out); out.toByteArray() }
                bitmap.recycle(); cropped.recycle()
                sendToTelegram(bytes)
                android.os.Handler(mainLooper).post { Toast.makeText(this, "Screenshot sent to Telegram", Toast.LENGTH_LONG).show() }
            } catch (e: Exception) {
                android.os.Handler(mainLooper).post { Toast.makeText(this, "Screenshot failed: ${e.message ?: "try again"}", Toast.LENGTH_LONG).show() }
            } finally { busy = false }
        }
    }

    private fun imageWidth(bitmap: android.graphics.Bitmap) = reader?.width ?: bitmap.width
    private fun imageHeight(bitmap: android.graphics.Bitmap) = reader?.height ?: bitmap.height

    private fun sendToTelegram(bytes: ByteArray) {
        val prefs = getSharedPreferences("momsnap", Context.MODE_PRIVATE)
        val token = prefs.getString("token", "") ?: ""
        val chat = prefs.getString("chat", "") ?: ""
        require(token.isNotBlank() && chat.isNotBlank()) { "Telegram settings are missing" }
        val boundary = "MomSnapBoundary${System.currentTimeMillis()}"
        val connection = (URL("https://api.telegram.org/bot$token/sendPhoto").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"; doOutput = true; connectTimeout = 15000; readTimeout = 20000
            setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
        }
        connection.outputStream.use { out ->
            fun field(name: String, value: String) {
                out.write("--$boundary\r\nContent-Disposition: form-data; name=\"$name\"\r\n\r\n$value\r\n".toByteArray())
            }
            field("chat_id", chat)
            out.write("--$boundary\r\nContent-Disposition: form-data; name=\"photo\"; filename=\"momsnap.jpg\"\r\nContent-Type: image/jpeg\r\n\r\n".toByteArray())
            out.write(bytes)
            out.write("\r\n--$boundary--\r\n".toByteArray())
        }
        val code = connection.responseCode
        val response = (if (code in 200..299) connection.inputStream else connection.errorStream)?.bufferedReader()?.use { it.readText() } ?: ""
        connection.disconnect()
        check(code in 200..299 && response.contains("\"ok\":true")) { "Telegram upload failed (HTTP $code). Check bot token and chat ID." }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL, "MomSnap screen capture", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        try { overlay?.let { windowManager?.removeView(it) } } catch (_: Exception) {}
        display?.release(); reader?.close(); projection?.stop(); executor.shutdownNow()
        super.onDestroy()
    }
}

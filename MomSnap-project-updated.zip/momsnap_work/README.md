# MomSnap — consent-based Android prototype

This Android Studio project implements a visible floating screenshot button. The phone owner must configure the Telegram bot and chat ID, grant the Android “display over other apps” permission, and approve Android's screen-capture prompt. A persistent notification indicates that screen capture is active. Tapping the floating 📸 button captures the current screen and uploads it to the configured Telegram chat.

## Important limitations
- This is source code, not a verified APK. It must be built and tested in Android Studio on the target Samsung phone.
- Android may block protected/DRM screens, and some system screens may appear blank.
- Android/Samsung may stop background services; battery optimization settings can affect reliability.
- Screen capture permission must be granted by the phone owner. Do not use this app without the owner's knowledge and consent.
- The bot token is stored in the app's private preferences on the phone. Do not share the token or put it in screenshots. For production, use a backend relay and stronger secret handling.
- This project intentionally does not hide the capture notification or bypass Android permissions.

## Setup
1. Open the project folder in Android Studio (Giraffe or newer) and allow Gradle sync.
2. Build > Build Bundle(s) / APK(s) > Build APK(s).
3. Install the APK on the Samsung phone.
4. Create a Telegram bot with BotFather. Send the bot a message from the recipient account and obtain that account's chat ID using a trusted Telegram bot/API method.
5. Open MomSnap on the phone. Enter the bot token and recipient chat ID, then save.
6. Tap “Enable floating screenshot button”. Grant “Display over other apps” if prompted, return to MomSnap, and tap Enable again. Approve Android's screen-capture prompt.
7. A persistent notification and floating 📸 button should appear. Tap the button to capture and send one screenshot.
8. Tap “Stop MomSnap” in the app to stop capture and remove the floating button.

The project targets Android 15 (API 35), minimum Android 8 (API 26). Device testing is required before relying on it.
